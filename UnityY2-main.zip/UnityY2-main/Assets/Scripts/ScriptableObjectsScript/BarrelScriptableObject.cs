using UnityEngine;

[CreateAssetMenu(fileName = "BarrelScriptableObject", menuName = "Obstacles Scriptable Objects/BarrelScriptableObject")]
public class BarrelScriptableObject : ScriptableObject
{
    public float BarrelSpeedMod;
}
