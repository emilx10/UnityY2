using UnityEngine;

[CreateAssetMenu(fileName = "FireHazardData", menuName = "Scriptable Objects/FireHazardData")]
public class FireHazardData : ScriptableObject
{
    
}
